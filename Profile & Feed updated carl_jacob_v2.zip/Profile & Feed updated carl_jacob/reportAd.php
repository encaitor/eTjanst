<?php
    session_start();
    $fromemail = $_SESSION['email'];
?>

<a href="mailto:admin@.com?subject=Feedback for webdevelopersnotes.com&body=The Tips and Tricks section is great">Send me an email</a>