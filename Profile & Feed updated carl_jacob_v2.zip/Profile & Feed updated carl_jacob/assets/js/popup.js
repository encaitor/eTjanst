<script language="JavaScript" type="text/javascript">
function login(showhide){
if(showhide == "show"){
    document.getElementById('openErrorModal').style.visibility="visible";
}else if(showhide == "hide"){
    document.getElementById('openErrorModal').style.visibility="hidden"; 
}
}
</script>