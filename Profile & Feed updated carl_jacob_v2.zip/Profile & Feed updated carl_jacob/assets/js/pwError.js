function pwNotSame() {
    alert("Your new password doesn't match, please try again!");
}

function wrongPW() {
    alert("You haven't entered your current password correctly, please try again!");
}