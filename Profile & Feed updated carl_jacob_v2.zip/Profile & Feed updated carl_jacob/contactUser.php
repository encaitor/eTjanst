<?php
    session_start();
    $fromemail = $_SESSION['email'];
    
    $retrieveusername1 = "SELECT username FROM ads";
    
?>

<a href="mailto:manish@simplygraphix.com?subject=Feedback for webdevelopersnotes.com&body=The Tips and Tricks section is great">Send me an email</a>