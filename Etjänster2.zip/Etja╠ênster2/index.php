
<html>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Eprojet test </title>
        
        <link rel="stylesheet" type="text/css" href="stylesheet.css">
        
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">
        
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/grids-responsive-min.css">

	<head>

        <div class="header">
            <div class="home-menu pure-menu pure-menu-horizontal pure-menu-fixed">
                <a class="pure-menu-heading" href=""><img src="assets/img/Controller-52.png"></a>
                
                <ul class="pure-menu-list">
                    <li class="pure-menu-item" ><a href="start.html" class="pure-menu-link">Home</a></li>
                </ul>
            </div>
        </div>

    <div id="header" class="pure-u-1"> 

        </div> 
		
	</head>
	
	<body>

	   <div id="layout" class="pure-g">
			
		<div id="content" class="pure-u-1 pure-u-sm-3-4">
			
			 <div class="posts">

                <!-- A single blog post -->
                <section class="post">
                    <header class="post-header">
                        <h2 class="post-title">Introducing Pure</h2>
                    </header>
                    <div class="post-description">
                        <p>
							Här kan det stå en massa kul grejer om hur ball det är att gå med i denna fräcka sidan. Wohooo!
                        </p>
                    </div>
                </section>
            </div>


			<div class="footer">
				<div class="pure-menu pure-menu-horizontal pure-u-1">
					<ul>
						<li class="pure-menu-item"><a href="#" class="pure-menu-link"> TEST</a></li>
						<li class="pure-menu-item"><a href="#" class="pure-menu-link"> TEST</a></li>
						<li class="pure-menu-item"><a href="#" class="pure-menu-link"> TEST</a></li>
					</ul>
				</div>
			</div>
		</div>
				
        <div id="feed" 	class="sidebar pure-u-1 pure-u-sm-1-4">

			<div class="sidebar">

				<h1 class="brand-title">Feed</h1>
				<h2 class="brand-tagline">Here you can find stuff.</h2>
                
                <table id="rubrik">
                <tr>
                <td>
                <table width="100%" border="0" cellpadding="3" cellspacing="0">
                <tr align="center" bgcolor="white"> 
                <td colspan="3"> Rubrik</td>
                </tr>
                <tr backgroundcolor="white"> 
                <td>En kontaktannons efter en soulmate</td>
                </tr>
                </table>
</td>
</tr>
</table>
		
			</div>
		</div>
	</div>

	</body>
</html>