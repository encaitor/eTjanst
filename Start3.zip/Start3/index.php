
<html>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="stylesheet" type="text/css" href="index.css">
        
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">
        
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/grids-responsive-min.css">

        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/grids-responsive-min.css">

         <title>start</title>


    <header>
    
            <div class="home-menu pure-menu pure-menu-horizontal pure-menu-fixed">
                
                <ul class="pure-menu-list">

                    <li class="pure-menu-item" ><a href="start.html" class="pure-menu-link">My Profile</a> "Användarnamn"</li>
                </ul>
            </div>
    

        <div id="spacer"></div>

    </header>
    <body>

	   <div class="pure-g">
			
	   <div class="feed pure-u-1 pure-u-sm-3-4">
			
			
            <h2>Annonser</h2>
                <!--Blog posts -->
                <section class="post">

                    <header class="post-header">
                        

                     <div class="post-description">
                     Annons 1
                    </div>
                        
                    <div class="post-description">
                        Annons 2
                    </div>
                    <div class="post-description">
                        Annons 3
                    </div>
                </header>
                        
            </section>
        


			<div class="footer">
				
                <div class="pure-menu pure-menu-horizontal pure-u-1">
					<ul>
						<li class="pure-menu-item"><a href="#" class="pure-menu-link">FAQ</a></li>
						<li class="pure-menu-item"><a href="#" class="pure-menu-link"> TEST</a></li>
						<li class="pure-menu-item"><a href="#" class="pure-menu-link"> TEST</a></li>
					</ul>
				</div>

			</div>

		</div>
				
        <div 	class="sidebar pure-u-1 pure-u-sm-1-4">

                <a class="pure-button" href="createAd"> Create ad</a>
				<h1 class="brand-title">Filter</h1>
	
		</div>
	</div>

	</body>
</html>