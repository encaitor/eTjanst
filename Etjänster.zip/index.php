<html>

	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Eprojet test </title>
		
		<link rel="stylesheet" type="text/css" href="stylesheet.css">
		<link rel="stylesheet" type="text/css" href="start.css">

		
		
		<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">
		
		<link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/grids-responsive-min.css">
		
		<link rel="stylesheet" href="css/stylesheet.css">
	</head>
	
	<body>

		<div id="header" class="pure-u-1">
			 
		
		
		<div id="login">
			<h3>Header</h3> 
        	<input type="email" 	placeholder="Email"> 
        	<input type="password" 	placeholder="Password"><br>

        	<label for="remember">
            <input id="remember" 	type="checkbox"> Remember me
        	</label>

        	<button type="submit" class="pure-button pure-button-primary">Sign in</button>

		</div>
		</div> 
	
	
		<div id="layout" class="pure-g">
			
		<div id="content" class="pure-u-1 pure-u-sm-3-4">
			<p>Content</p>
			
			 <div class="posts">
                <h1 class="content-subhead">Pinned Post</h1>

                <!-- A single blog post -->
                <section class="post">
                    <header class="post-header">
                        <h2 class="post-title">Introducing Pure</h2>
                    </header>
                    <div class="post-description">
                        <p>
							Här kan det stå en massa kul grejer om hur ball det är att gå med i denna fräcka sidan. Wohooo!
                        </p>
                    </div>
                </section>
            </div>


				<div class="footer">
					<div class="pure-menu pure-menu-horizontal pure-u-1">
						<ul>
							<li class="pure-menu-item"><a href="#" class="pure-menu-link"> TEST</a></li>
							<li class="pure-menu-item"><a href="#" class="pure-menu-link"> TEST</a></li>
							<li class="pure-menu-item"><a href="#" class="pure-menu-link"> TEST</a></li>
						</ul>
					</div>
				</div>
		</div>
				<div id="feed" 	class="sidebar pure-u-1 pure-u-sm-1-4">

			<div class="header">

				<h1 class="brand-title">Feed</h1>
				<h2 class="brand-tagline">Here you can find stuff.</h2>
			
			</div>
		</div>
	</div>

	</body>
</html>